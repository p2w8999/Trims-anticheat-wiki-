package com.kodari.trimskitanticheat.permissions;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.PermissionSet;
import net.minecraft.server.permissions.Permissions;

/**
 * Server-authoritative permission evaluation.
 * Fails closed if privileges are absent or malformed.
 */
public final class PermissionManager {

    private PermissionManager() {
    }

    /**
     * Checks if a player has administrative or staff permission to receive alerts or execute /tac.
     */
    public static boolean hasStaffPermission(ServerPlayer player) {
        if (player == null) return false;
        int minLevel = TrimskitAntiCheat.getInstance().getConfigManager().getConfig().system.minStaffPermissionLevel;
        return checkPermissionLevel(player.permissions(), minLevel);
    }

    /**
     * Checks if a command source stack has permission for staff commands.
     */
    public static boolean hasStaffPermission(CommandSourceStack source) {
        if (source == null) return false;
        int minLevel = TrimskitAntiCheat.getInstance().getConfigManager().getConfig().system.minStaffPermissionLevel;
        return checkPermissionLevel(source.permissions(), minLevel);
    }

    private static boolean checkPermissionLevel(PermissionSet set, int minLevel) {
        if (set == null) return false;
        if (minLevel <= 1 && set.hasPermission(Permissions.COMMANDS_MODERATOR)) return true;
        if (minLevel <= 2 && set.hasPermission(Permissions.COMMANDS_GAMEMASTER)) return true;
        if (minLevel <= 3 && set.hasPermission(Permissions.COMMANDS_ADMIN)) return true;
        return set.hasPermission(Permissions.COMMANDS_OWNER);
    }
}
