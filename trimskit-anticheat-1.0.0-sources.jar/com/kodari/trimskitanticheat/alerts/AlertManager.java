package com.kodari.trimskitanticheat.alerts;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import com.kodari.trimskitanticheat.config.SystemConfig;
import com.kodari.trimskitanticheat.permissions.PermissionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.violations.Violation;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages dispatching formatted, rate-limited alerts to authorized staff members and server logs.
 */
public class AlertManager {

    private final Map<String, Long> lastAlertTime = new ConcurrentHashMap<>();

    public void sendAlert(Violation violation) {
        SystemConfig sysConfig = TrimskitAntiCheat.getInstance().getConfigManager().getConfig().system;

        // Anti-spam rate limiting per check per player
        String alertKey = violation.playerUuid() + ":" + violation.checkId();
        long now = System.currentTimeMillis();
        Long last = lastAlertTime.get(alertKey);
        if (last != null && now - last < sysConfig.alertCooldownMs) {
            return;
        }
        lastAlertTime.put(alertKey, now);

        // Console Logging
        if (sysConfig.logAlertsToConsole) {
            TrimskitAntiCheat.LOGGER.info("[ALERT] {} flagged {} (+{}) VL: {} (Confidence: {}%) | Evidence: {}",
                    violation.playerName(),
                    violation.checkName(),
                    String.format("%.1f", violation.weight()),
                    String.format("%.1f", violation.violationLevel()),
                    (int) (violation.confidence() * 100),
                    violation.evidence()
            );
        }

        if (!sysConfig.staffAlertsEnabled) {
            return;
        }

        MinecraftServer server = TrimskitAntiCheat.getInstance().getServer();
        if (server == null) return;

        // Interactive staff alert component
        MutableComponent message = Component.literal("§8[§cTrimskit§8] §f")
                .append(Component.literal(violation.playerName()).withStyle(ChatFormatting.RED))
                .append(Component.literal(" failed §e" + violation.checkName()))
                .append(Component.literal(String.format(" §7[VL: §c%.1f§7, Conf: §e%d%%§7]",
                        violation.violationLevel(), (int) (violation.confidence() * 100))))
                .withStyle(style -> style
                        .withHoverEvent(new HoverEvent.ShowText(
                                Component.literal("§7Check ID: §f" + violation.checkId() + "\n"
                                        + "§7Evidence: §f" + violation.evidence() + "\n\n"
                                        + "§eClick to inspect player.")))
                        .withClickEvent(new ClickEvent.RunCommand("/tac inspect " + violation.playerName()))
                );

        for (ServerPlayer staff : server.getPlayerList().getPlayers()) {
            if (PermissionManager.hasStaffPermission(staff)) {
                PlayerData staffData = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(staff);
                if (staffData == null || staffData.isStaffAlertsEnabled()) {
                    staff.sendSystemMessage(message);
                }
            }
        }
    }

    public void clearCooldowns() {
        lastAlertTime.clear();
    }
}
