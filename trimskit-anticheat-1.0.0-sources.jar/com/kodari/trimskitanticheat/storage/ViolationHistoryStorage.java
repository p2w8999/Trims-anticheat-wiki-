package com.kodari.trimskitanticheat.storage;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import com.kodari.trimskitanticheat.violations.Violation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.time.Instant;

/**
 * Storage handler for persistent violation auditing and log rotation.
 */
public class ViolationHistoryStorage {

    private final Path logPath;

    public ViolationHistoryStorage(Path storageDir) {
        this.logPath = storageDir.resolve("violations.log");
    }

    public synchronized void appendViolation(Violation violation) {
        File file = logPath.toFile();
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            String line = String.format("[%s] %s (%s) failed %s (VL: %.1f, Conf: %.2f) - Evidence: %s%n",
                    Instant.ofEpochMilli(violation.timestampMs()).toString(),
                    violation.playerName(),
                    violation.playerUuid(),
                    violation.checkId(),
                    violation.violationLevel(),
                    violation.confidence(),
                    violation.evidence()
            );
            writer.write(line);
        } catch (IOException e) {
            TrimskitAntiCheat.LOGGER.error("Failed to write violation to log file: {}", e.getMessage());
        }
    }
}
