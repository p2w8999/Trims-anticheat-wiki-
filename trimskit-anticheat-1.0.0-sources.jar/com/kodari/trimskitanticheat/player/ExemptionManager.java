package com.kodari.trimskitanticheat.player;

import com.kodari.trimskitanticheat.util.CollisionUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;

/**
 * Centrally evaluates dynamic exemptions for players based on game state,
 * environmental surroundings, and server-side events.
 */
public final class ExemptionManager {

    private ExemptionManager() {
    }

    /**
     * Checks if a player is currently exempted for movement-related checks.
     */
    public static boolean isExemptFromMovement(PlayerData data, ServerPlayer player) {
        if (player.isCreative() || player.isSpectator()) {
            return true;
        }
        if (player.isPassenger()) {
            return true;
        }
        if (player.isFallFlying()) {
            return true;
        }

        long currentTick = data.getCurrentServerTick();

        // Teleport grace period (20 ticks / 1 second)
        if (currentTick - data.getLastTeleportTick() < 20) {
            return true;
        }

        // Respawn / join grace period (30 ticks)
        if (currentTick - data.getJoinTick() < 30 || currentTick - data.getLastRespawnTick() < 30) {
            return true;
        }

        // Knockback / external velocity grace period (25 ticks)
        if (currentTick - data.getLastVelocityTick() < 25) {
            return true;
        }

        return false;
    }

    /**
     * Checks if a player is currently in or interacting with fluids (water/lava).
     */
    public static boolean isInFluids(ServerPlayer player) {
        return player.isInWater() || player.isInLava();
    }

    /**
     * Checks if a player is exempted from speed checks due to environmental blocks or effects.
     */
    public static boolean isExemptFromSpeed(PlayerData data, ServerPlayer player) {
        if (isExemptFromMovement(data, player)) {
            return true;
        }
        AABB box = player.getBoundingBox();
        if (CollisionUtil.isNearIce(player.level(), box) || CollisionUtil.isNearSlimeOrHoney(player.level(), box)) {
            return true;
        }
        return isInFluids(player);
    }

    /**
     * Checks if a player is exempted from fly checks due to climbing or fluids.
     */
    public static boolean isExemptFromFly(PlayerData data, ServerPlayer player) {
        if (isExemptFromMovement(data, player)) {
            return true;
        }
        AABB box = player.getBoundingBox();
        if (CollisionUtil.isNearClimbable(player.level(), box)) {
            return true;
        }
        if (CollisionUtil.isInWebOrPowderSnow(player.level(), box)) {
            return true;
        }
        return isInFluids(player);
    }

    /**
     * Checks if a player is exempted from combat checks.
     */
    public static boolean isExemptFromCombat(PlayerData data, ServerPlayer player) {
        if (player.isSpectator()) {
            return true;
        }
        long currentTick = data.getCurrentServerTick();
        return currentTick - data.getJoinTick() < 20 || currentTick - data.getLastRespawnTick() < 20;
    }
}
