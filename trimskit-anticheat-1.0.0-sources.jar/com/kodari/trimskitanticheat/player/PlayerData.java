package com.kodari.trimskitanticheat.player;

import com.kodari.trimskitanticheat.aim.RotationHistory;
import com.kodari.trimskitanticheat.combat.CombatTracker;
import com.kodari.trimskitanticheat.inventory.InventoryActionTracker;
import com.kodari.trimskitanticheat.movement.MovementState;
import com.kodari.trimskitanticheat.network.PacketThrottler;
import com.kodari.trimskitanticheat.violations.Violation;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Encapsulates all state, rolling statistical histories, violation tracking,
 * and environmental flags for a connected player.
 */
public class PlayerData {

    private final UUID uuid;
    private String playerName;

    private final MovementState movementState = new MovementState();
    private final RotationHistory rotationHistory = new RotationHistory();
    private final CombatTracker combatTracker = new CombatTracker();
    private final InventoryActionTracker inventoryTracker = new InventoryActionTracker();
    private final PacketThrottler packetThrottler = new PacketThrottler();

    private final Map<String, Double> violationLevels = new ConcurrentHashMap<>();
    private final Deque<Violation> violationHistory = new ArrayDeque<>(100);

    private long joinTick;
    private long lastRespawnTick;
    private long lastTeleportTick;
    private long lastVelocityTick;
    private long currentServerTick;
    private int latencyPingMs;

    private boolean debugMode;
    private boolean staffAlertsEnabled = true;

    public PlayerData(UUID uuid, String playerName, long currentTick) {
        this.uuid = uuid;
        this.playerName = playerName;
        this.joinTick = currentTick;
        this.lastRespawnTick = currentTick;
        this.lastTeleportTick = currentTick;
        this.lastVelocityTick = currentTick;
        this.currentServerTick = currentTick;
    }

    public UUID getUuid() { return uuid; }
    public String getPlayerName() { return playerName; }
    public void setPlayerName(String playerName) { this.playerName = playerName; }

    public MovementState getMovementState() { return movementState; }
    public RotationHistory getRotationHistory() { return rotationHistory; }
    public CombatTracker getCombatTracker() { return combatTracker; }
    public InventoryActionTracker getInventoryTracker() { return inventoryTracker; }
    public PacketThrottler getPacketThrottler() { return packetThrottler; }

    public double getViolationLevel(String checkId) {
        return violationLevels.getOrDefault(checkId, 0.0);
    }

    public void setViolationLevel(String checkId, double vl) {
        violationLevels.put(checkId, Math.max(0.0, vl));
    }

    public Map<String, Double> getViolationLevels() {
        return violationLevels;
    }

    public synchronized void addViolationToHistory(Violation violation) {
        if (violationHistory.size() >= 100) {
            violationHistory.pollFirst();
        }
        violationHistory.addLast(violation);
    }

    public synchronized Violation[] getViolationHistory() {
        return violationHistory.toArray(new Violation[0]);
    }

    public long getJoinTick() { return joinTick; }
    public long getLastRespawnTick() { return lastRespawnTick; }
    public void setLastRespawnTick(long lastRespawnTick) { this.lastRespawnTick = lastRespawnTick; }
    public long getLastTeleportTick() { return lastTeleportTick; }
    public void setLastTeleportTick(long lastTeleportTick) { this.lastTeleportTick = lastTeleportTick; }
    public long getLastVelocityTick() { return lastVelocityTick; }
    public void setLastVelocityTick(long lastVelocityTick) { this.lastVelocityTick = lastVelocityTick; }

    public long getCurrentServerTick() { return currentServerTick; }
    public void setCurrentServerTick(long currentServerTick) { this.currentServerTick = currentServerTick; }

    public int getLatencyPingMs() { return latencyPingMs; }
    public void setLatencyPingMs(int latencyPingMs) { this.latencyPingMs = latencyPingMs; }

    public boolean isDebugMode() { return debugMode; }
    public void setDebugMode(boolean debugMode) { this.debugMode = debugMode; }

    public boolean isStaffAlertsEnabled() { return staffAlertsEnabled; }
    public void setStaffAlertsEnabled(boolean staffAlertsEnabled) { this.staffAlertsEnabled = staffAlertsEnabled; }

    public void cleanup() {
        violationLevels.clear();
        synchronized (this) {
            violationHistory.clear();
        }
        combatTracker.clear();
        rotationHistory.clear();
        packetThrottler.reset();
    }
}
