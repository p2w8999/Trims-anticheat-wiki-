package com.kodari.trimskitanticheat.player;

/**
 * Categorized exemptions for legitimate Minecraft game mechanics.
 */
public enum ExemptionType {
    TELEPORT,
    RESPAWN,
    CREATIVE_OR_SPECTATOR,
    VEHICLE,
    ELYTRA_GLIDING,
    RIPTIDE,
    VELOCITY_KNOCKBACK,
    ICE_OR_SLIME,
    CLIMBING,
    FLUID,
    WEB_OR_POWDER_SNOW,
    JOINING
}
