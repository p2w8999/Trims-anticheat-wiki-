package com.kodari.trimskitanticheat.player;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import com.kodari.trimskitanticheat.config.DecayConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages player state lifecycle, registrations, lookups, and per-tick updates.
 */
public class PlayerDataManager {

    private final Map<UUID, PlayerData> players = new ConcurrentHashMap<>();

    public PlayerData getPlayerData(UUID uuid) {
        return players.get(uuid);
    }

    public PlayerData getPlayerData(ServerPlayer player) {
        if (player == null) return null;
        return players.get(player.getUUID());
    }

    public PlayerData registerPlayer(ServerPlayer player, long currentTick) {
        PlayerData data = new PlayerData(player.getUUID(), player.getScoreboardName(), currentTick);
        players.put(player.getUUID(), data);
        TrimskitAntiCheat.LOGGER.debug("Registered tracking session for player: {} ({})", player.getScoreboardName(), player.getUUID());
        return data;
    }

    public void removePlayer(UUID uuid) {
        PlayerData removed = players.remove(uuid);
        if (removed != null) {
            removed.cleanup();
            TrimskitAntiCheat.LOGGER.debug("Cleaned up tracking session for player: {}", removed.getPlayerName());
        }
    }

    public Collection<PlayerData> getAllPlayers() {
        return players.values();
    }

    /**
     * Called on each server tick to update ping, current tick, and trigger decay.
     */
    public void tick(MinecraftServer server, long currentTick) {
        DecayConfig decayConfig = TrimskitAntiCheat.getInstance().getConfigManager().getConfig().decay;
        boolean shouldDecay = (currentTick % Math.max(1, decayConfig.decayIntervalTicks)) == 0;

        for (PlayerData data : players.values()) {
            data.setCurrentServerTick(currentTick);

            ServerPlayer player = server.getPlayerList().getPlayer(data.getUuid());
            if (player != null) {
                // Keep name updated
                data.setPlayerName(player.getScoreboardName());
                // Update ping latency
                data.setLatencyPingMs(player.connection.latency());
                // Record target bounding box for lag-compensated combat tracking
                data.getCombatTracker().recordEntityPosition(player, currentTick);
            }

            if (shouldDecay) {
                TrimskitAntiCheat.getInstance().getViolationManager().decayPlayerViolations(data);
            }
        }
    }

    public void clearAll() {
        for (PlayerData data : players.values()) {
            data.cleanup();
        }
        players.clear();
    }
}
