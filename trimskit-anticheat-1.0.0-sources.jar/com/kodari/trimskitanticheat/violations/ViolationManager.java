package com.kodari.trimskitanticheat.violations;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import com.kodari.trimskitanticheat.config.AntiCheatConfig;
import com.kodari.trimskitanticheat.config.DecayConfig;
import com.kodari.trimskitanticheat.config.PunishmentConfig;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;

/**
 * Centrally tracks, escalates, decays, and punishes violation levels across all players.
 */
public class ViolationManager {

    public void handleViolation(PlayerData data, String checkId, String checkName, double weight, double confidence, String evidence) {
        if (data == null) return;

        double currentVL = data.getViolationLevel(checkId);
        double newVL = currentVL + weight;
        data.setViolationLevel(checkId, newVL);

        Violation violation = new Violation(
                checkId,
                checkName,
                data.getUuid(),
                data.getPlayerName(),
                newVL,
                weight,
                confidence,
                evidence,
                System.currentTimeMillis()
        );

        data.addViolationToHistory(violation);

        // Dispatch alerts to staff
        TrimskitAntiCheat.getInstance().getAlertManager().sendAlert(violation);

        // Evaluate automated punishments if configured
        evaluatePunishment(data, checkId, newVL);
    }

    private void evaluatePunishment(PlayerData data, String checkId, double vl) {
        AntiCheatConfig config = TrimskitAntiCheat.getInstance().getConfigManager().getConfig();
        PunishmentConfig punishment = config.punishment;

        if (!punishment.enabled) {
            return;
        }

        MinecraftServer server = TrimskitAntiCheat.getInstance().getServer();
        if (server == null) return;

        ServerPlayer player = server.getPlayerList().getPlayer(data.getUuid());
        if (player == null) return;

        if (vl >= punishment.banThreshold) {
            TrimskitAntiCheat.LOGGER.warn("Player {} exceeded ban threshold on check {} (VL: {}). Executing ban command.",
                    data.getPlayerName(), checkId, vl);
            String command = punishment.banCommand.replace("%player%", data.getPlayerName());
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), command);
        } else if (vl >= punishment.kickThreshold) {
            TrimskitAntiCheat.LOGGER.warn("Player {} exceeded kick threshold on check {} (VL: {}). Disconnecting.",
                    data.getPlayerName(), checkId, vl);
            player.connection.disconnect(Component.literal(punishment.kickMessage));
        }
    }

    /**
     * Executes decay step on all violation levels for a player.
     */
    public void decayPlayerViolations(PlayerData data) {
        DecayConfig decay = TrimskitAntiCheat.getInstance().getConfigManager().getConfig().decay;
        Map<String, Double> vls = data.getViolationLevels();

        for (Map.Entry<String, Double> entry : vls.entrySet()) {
            double current = entry.getValue();
            if (current <= 0.0) continue;

            // Linear decay
            double decayed = current - decay.decayAmountPerInterval;
            // Exponential decay factor
            decayed -= (decayed * decay.exponentialDecayFactor);

            if (decayed < 0.1) {
                entry.setValue(0.0);
            } else {
                entry.setValue(decayed);
            }
        }
    }
}
