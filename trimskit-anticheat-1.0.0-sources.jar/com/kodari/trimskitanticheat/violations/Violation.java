package com.kodari.trimskitanticheat.violations;

import java.util.UUID;

/**
 * Immutable record of a detected anomaly or confirmed violation.
 */
public record Violation(
        String checkId,
        String checkName,
        UUID playerUuid,
        String playerName,
        double violationLevel,
        double weight,
        double confidence,
        String evidence,
        long timestampMs
) {
}
