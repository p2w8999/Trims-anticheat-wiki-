package com.kodari.trimskitanticheat.client;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client-side entrypoint for Trimskit AntiCheat.
 *
 * <p><strong>Security Model & Non-Invasive Guarantee:</strong>
 * This component is completely optional and strictly supplementary.
 * The server is 100% authoritative and will never trust client-side claims,
 * self-certifications, or telemetry for gameplay validation.
 *
 * <p>No hardware identifiers, personal files, or intrusive scans are executed.
 * Telemetry is limited to voluntary debug diagnostics and latency indicators.
 */
public class TrimskitAntiCheatClient implements ClientModInitializer {

    public static final Logger CLIENT_LOGGER = LoggerFactory.getLogger("TrimskitClient");

    @Override
    public void onInitializeClient() {
        CLIENT_LOGGER.info("Trimskit AntiCheat client component initialized.");
        CLIENT_LOGGER.info("Running in transparent diagnostic mode. Server remains 100% authoritative.");
    }
}
