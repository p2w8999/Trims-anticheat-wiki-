package com.kodari.trimskitanticheat.network;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Tracks packet arrival cadence to detect client-side Timer cheats and packet flooding.
 */
public class PacketThrottler {

    private final Deque<Long> packetArrivals = new ArrayDeque<>(100);

    /**
     * Records a movement packet arrival and returns the packet count in the last 1000ms.
     */
    public synchronized int recordPacketAndGetRate() {
        long now = System.currentTimeMillis();
        packetArrivals.addLast(now);

        long windowStart = now - 1000L;
        while (!packetArrivals.isEmpty() && packetArrivals.peekFirst() < windowStart) {
            packetArrivals.pollFirst();
        }

        return packetArrivals.size();
    }

    public synchronized void reset() {
        packetArrivals.clear();
    }
}
