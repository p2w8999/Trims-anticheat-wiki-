package com.kodari.trimskitanticheat.network;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import net.minecraft.resources.Identifier;

/**
 * Handles optional client telemetry from players with Trimskit Client installed.
 * All client self-reports are supplementary and never trusted for gameplay authorization.
 */
public final class NetworkTelemetry {

    public static final Identifier TELEMETRY_CHANNEL = Identifier.fromNamespaceAndPath("trimskit", "telemetry");

    private NetworkTelemetry() {
    }

    /**
     * Validates client telemetry payload for sanity.
     */
    public static boolean validateTelemetry(long clientSentTimestamp, int reportedFps) {
        long now = System.currentTimeMillis();
        // Plausibility check: timestamps shouldn't be hours in the future
        if (clientSentTimestamp > now + 5000L) {
            TrimskitAntiCheat.LOGGER.debug("Client sent anomalous future telemetry timestamp: {}", clientSentTimestamp);
            return false;
        }
        if (reportedFps < 0 || reportedFps > 2000) {
            return false;
        }
        return true;
    }
}
