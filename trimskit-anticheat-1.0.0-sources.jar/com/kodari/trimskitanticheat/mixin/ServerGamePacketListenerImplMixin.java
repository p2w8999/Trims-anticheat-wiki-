package com.kodari.trimskitanticheat.mixin;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin intercepting incoming network packets for server-authoritative validation
 * before state modification or world event execution.
 */
@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerGamePacketListenerImplMixin {

    @Shadow
    public ServerPlayer player;

    @Inject(method = "handleMovePlayer", at = @At("HEAD"))
    private void trimskit$onMovePlayer(ServerboundMovePlayerPacket packet, CallbackInfo ci) {
        if (player == null) return;
        PlayerData data = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(player);
        if (data != null) {
            TrimskitAntiCheat.getInstance().getCheckManager().processMovement(data, player, packet);
        }
    }

    @Inject(method = "handleAttack", at = @At("HEAD"), cancellable = true)
    private void trimskit$onAttack(ServerboundAttackPacket packet, CallbackInfo ci) {
        if (player == null) return;
        PlayerData data = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(player);
        if (data != null) {
            boolean valid = TrimskitAntiCheat.getInstance().getCheckManager().processAttack(data, player, packet);
            if (!valid) {
                // Reject invalid/cheated combat attacks
                ci.cancel();
            }
        }
    }

    @Inject(method = "handlePlayerAction", at = @At("HEAD"))
    private void trimskit$onPlayerAction(ServerboundPlayerActionPacket packet, CallbackInfo ci) {
        if (player == null) return;
        PlayerData data = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(player);
        if (data != null) {
            // Track block digging, eating release, or drop action
            if (packet.getAction() == ServerboundPlayerActionPacket.Action.RELEASE_USE_ITEM) {
                int usedTicks = player.getTicksUsingItem();
                TrimskitAntiCheat.getInstance().getCheckManager().fastUseCheck.check(
                        data, player, player.getUseItem(), usedTicks);
            }
        }
    }
}
