package com.kodari.trimskitanticheat.checks.combat;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.util.MathUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Validates attacker look angles relative to target position, preventing blind
 * or impossible 180/360 combat attacks.
 */
public class AngleCheck extends Check {

    public AngleCheck() {
        super("combat_angle", "Angle", "Detects impossible attack angles and field-of-view anomalies.", CheckCategory.COMBAT);
    }

    public boolean check(PlayerData data, ServerPlayer attacker, Entity target) {
        if (!isEnabled() || ExemptionManager.isExemptFromCombat(data, attacker)) {
            return true;
        }

        Vec3 eyePos = attacker.getEyePosition();
        Vec3 lookVec = attacker.getViewVector(1.0F);
        Vec3 targetCenter = target.getBoundingBox().getCenter();

        double angle = MathUtil.angleBetween(lookVec, eyePos, targetCenter);
        double maxAngle = getConfig().getDouble("maxAngleDegrees", 95.0);

        if (angle > maxAngle) {
            double confidence = Math.min(1.0, 0.70 + ((angle - maxAngle) / 90.0));
            flag(data, getConfig().violationWeight, confidence,
                    String.format("angle=%.1f° > max=%.1f°, target=%s", angle, maxAngle, target.getName().getString()));
            return false;
        }

        return true;
    }
}
