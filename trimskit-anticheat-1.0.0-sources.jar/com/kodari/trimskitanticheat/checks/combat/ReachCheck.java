package com.kodari.trimskitanticheat.checks.combat;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.util.MathUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Server-authoritative combat reach validation.
 * Uses ray-to-AABB distance calculation with historical lag compensation to detect
 * subtle 3.01+ reach modifications without false flagging latency-induced delays.
 */
public class ReachCheck extends Check {

    public ReachCheck() {
        super("combat_reach", "Reach", "Detects impossible attack distances and extended reach hacks.", CheckCategory.COMBAT);
    }

    public boolean check(PlayerData data, ServerPlayer attacker, Entity target) {
        if (!isEnabled() || ExemptionManager.isExemptFromCombat(data, attacker)) {
            return true;
        }

        Vec3 eyePos = attacker.getEyePosition();
        long now = System.currentTimeMillis();
        int ping = Math.max(0, data.getLatencyPingMs());

        // Lag compensation: rewind target bounding box based on attacker latency (bounded at 400ms)
        long compensatedTime = now - Math.min(ping, 400);
        AABB targetBox = data.getCombatTracker().findHistoricalBox(target.getId(), compensatedTime, target.getBoundingBox());

        // Ray to AABB distance
        double distance = MathUtil.distanceToAABB(eyePos, targetBox);

        double maxReach = attacker.isCreative()
                ? getConfig().getDouble("maxCreativeReach", 5.0)
                : getConfig().getDouble("maxSurvivalReach", 3.05);

        // Allow slight tolerance for server-side tick alignment and bounding box edge rounding
        double tolerance = 0.15;
        double threshold = maxReach + tolerance;

        if (distance > threshold) {
            double excess = distance - maxReach;
            double confidence = Math.min(1.0, 0.75 + (excess * 0.5));
            flag(data, getConfig().violationWeight, confidence,
                    String.format("dist=%.3f, max=%.2f, ping=%dms, excess=+%.3f, target=%s",
                            distance, maxReach, ping, excess, target.getName().getString()));
            return false;
        }

        return true;
    }
}
