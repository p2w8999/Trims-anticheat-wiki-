package com.kodari.trimskitanticheat.checks.combat;

import com.kodari.trimskitanticheat.aim.AimAnalysis;
import com.kodari.trimskitanticheat.aim.RotationHistory;
import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Statistical aim analysis detecting Vape V4-style smoothed aim assist,
 * robotic rotation interpolation, and sensitivity GCD anomalies.
 */
public class AimConsistencyCheck extends Check {

    public AimConsistencyCheck() {
        super("combat_aimconsistency", "AimConsistency", "Detects algorithmic aim assistance, smoothed tracking, and GCD anomalies.", CheckCategory.COMBAT);
    }

    public void check(PlayerData data, ServerPlayer attacker) {
        if (!isEnabled() || ExemptionManager.isExemptFromCombat(data, attacker)) {
            return;
        }

        RotationHistory.RotationSample[] samples = data.getRotationHistory().getRecentSamples();
        int minSamples = (int) getConfig().getDouble("minSampleCount", 20.0);

        if (samples.length < minSamples) {
            return;
        }

        double pitchVariance = AimAnalysis.calculateDeltaVariance(samples, true);
        double yawVariance = AimAnalysis.calculateDeltaVariance(samples, false);

        // Algorithmic aimbots often interpolate with fixed angular steps resulting in near-zero variance
        if (yawVariance >= 0.0 && yawVariance < 0.0005) {
            // Verify that movement actually occurred rather than player sitting completely still
            float totalDelta = 0.0F;
            for (RotationHistory.RotationSample s : samples) {
                totalDelta += s.deltaYaw();
            }

            if (totalDelta > 5.0F) {
                flag(data, getConfig().violationWeight, 0.85,
                        String.format("unnatural linear yaw variance=%.6f over %d samples", yawVariance, samples.length));
            }
        }
    }
}
