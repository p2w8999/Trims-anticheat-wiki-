package com.kodari.trimskitanticheat.checks.combat;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Validates attack cadence and detects automated click macros or autoclickers.
 */
public class AttackRateCheck extends Check {

    public AttackRateCheck() {
        super("combat_attackrate", "AttackRate", "Detects automated clicking macros and impossible CPS frequencies.", CheckCategory.COMBAT);
    }

    public boolean check(PlayerData data, ServerPlayer attacker) {
        if (!isEnabled() || ExemptionManager.isExemptFromCombat(data, attacker)) {
            return true;
        }

        int cps = data.getCombatTracker().recordAttackAndGetCPS();
        double maxCps = getConfig().getDouble("maxClicksPerSecond", 22.0);

        if (cps > maxCps) {
            double confidence = Math.min(1.0, 0.75 + ((cps - maxCps) * 0.05));
            flag(data, getConfig().violationWeight, confidence,
                    String.format("CPS=%d > max=%.0f", cps, maxCps));
            return false;
        }

        return true;
    }
}
