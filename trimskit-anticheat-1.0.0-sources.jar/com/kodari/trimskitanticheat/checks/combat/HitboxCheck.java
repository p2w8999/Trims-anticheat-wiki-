package com.kodari.trimskitanticheat.checks.combat;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

/**
 * Validates attack ray intersection against authoritative target bounding boxes,
 * detecting Vape-style client-side hitbox expansions.
 */
public class HitboxCheck extends Check {

    public HitboxCheck() {
        super("combat_hitbox", "Hitbox", "Detects expanded client hitboxes and off-target attack interactions.", CheckCategory.COMBAT);
    }

    public boolean check(PlayerData data, ServerPlayer attacker, Entity target) {
        if (!isEnabled() || ExemptionManager.isExemptFromCombat(data, attacker)) {
            return true;
        }

        Vec3 eyePos = attacker.getEyePosition();
        Vec3 lookVec = attacker.getViewVector(1.0F);

        long now = System.currentTimeMillis();
        int ping = Math.max(0, data.getLatencyPingMs());
        long compensatedTime = now - Math.min(ping, 400);

        AABB targetBox = data.getCombatTracker().findHistoricalBox(target.getId(), compensatedTime, target.getBoundingBox());
        double expansion = getConfig().getDouble("boxExpansion", 0.15);
        AABB expandedBox = targetBox.inflate(expansion);

        // Ray casting from eye position along look vector for 6 blocks
        Vec3 rayEnd = eyePos.add(lookVec.scale(6.0));
        Optional<Vec3> hit = expandedBox.clip(eyePos, rayEnd);

        if (hit.isEmpty()) {
            flag(data, getConfig().violationWeight, 0.85,
                    String.format("raycast missed target %s bounding box (expansion=%.2f)",
                            target.getName().getString(), expansion));
            return false;
        }

        return true;
    }
}
