package com.kodari.trimskitanticheat.checks;

/**
 * Result evaluation of a check execution on an action.
 */
public record CheckResult(boolean passed, double addedWeight, double confidence, String evidence) {

    public static CheckResult pass() {
        return new CheckResult(true, 0.0, 0.0, "");
    }

    public static CheckResult fail(double addedWeight, double confidence, String evidence) {
        return new CheckResult(false, addedWeight, confidence, evidence);
    }
}
