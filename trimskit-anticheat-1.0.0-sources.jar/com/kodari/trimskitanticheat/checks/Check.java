package com.kodari.trimskitanticheat.checks;

import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import com.kodari.trimskitanticheat.config.CheckConfig;
import com.kodari.trimskitanticheat.player.PlayerData;

/**
 * Base abstraction for all anti-cheat detection checks.
 */
public abstract class Check {

    private final String id;
    private final String name;
    private final String description;
    private final CheckCategory category;

    public Check(String id, String name, String description, CheckCategory category) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public CheckCategory getCategory() { return category; }

    public CheckConfig getConfig() {
        return TrimskitAntiCheat.getInstance().getConfigManager().getConfig().getCheckConfig(id);
    }

    public boolean isEnabled() {
        return getConfig().enabled;
    }

    public void setEnabled(boolean enabled) {
        getConfig().enabled = enabled;
        TrimskitAntiCheat.getInstance().getConfigManager().save();
    }

    /**
     * Flags a violation for the player through the central ViolationManager.
     */
    protected void flag(PlayerData data, double weight, double confidence, String evidence) {
        TrimskitAntiCheat.getInstance().getViolationManager().handleViolation(
                data,
                id,
                name,
                weight,
                confidence,
                evidence
        );
    }
}
