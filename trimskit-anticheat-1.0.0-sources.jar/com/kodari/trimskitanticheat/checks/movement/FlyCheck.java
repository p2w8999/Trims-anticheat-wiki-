package com.kodari.trimskitanticheat.checks.movement;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.movement.MovementState;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Detects sustained unsupported flight, vertical hovering, and glide modifications.
 */
public class FlyCheck extends Check {

    public FlyCheck() {
        super("movement_fly", "Fly", "Detects unsupported flight and abnormal vertical motion.", CheckCategory.MOVEMENT);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromFly(data, player)) {
            return;
        }

        MovementState state = data.getMovementState();
        int airTicks = state.getAirTicks();
        double deltaY = state.getDeltaY();
        int maxAirTicks = (int) getConfig().getDouble("maxAirTicks", 22.0);

        if (airTicks > maxAirTicks) {
            // Ascending or hovering while unsupported in air
            if (deltaY >= -0.01) {
                double confidence = Math.min(1.0, 0.80 + ((airTicks - maxAirTicks) * 0.02));
                flag(data, getConfig().violationWeight, confidence,
                        String.format("airTicks=%d, deltaY=%.3f (expected negative fall motion)", airTicks, deltaY));
            } else if (deltaY > -0.08 && airTicks > 35) {
                // Suspiciously slow glide motion
                flag(data, getConfig().violationWeight * 0.5, 0.75,
                        String.format("slow glide: airTicks=%d, deltaY=%.3f", airTicks, deltaY));
            }
        }
    }
}
