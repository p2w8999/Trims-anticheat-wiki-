package com.kodari.trimskitanticheat.checks.movement;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.movement.MovementState;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Validates horizontal movement speed envelopes against kinematic limits,
 * sprinting physics, jump-sprint boosts, and status effect multipliers.
 */
public class SpeedCheck extends Check {

    public SpeedCheck() {
        super("movement_speed", "Speed", "Detects horizontal speed and acceleration anomalies.", CheckCategory.MOVEMENT);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromSpeed(data, player)) {
            return;
        }

        MovementState state = data.getMovementState();
        double deltaXZ = state.getDeltaXZ();

        // Base walking/sprinting limit
        double maxSpeed = 0.286; // standard sprint
        if (state.getAirTicks() > 0 && state.getAirTicks() <= 10) {
            // Jump-sprint initial velocity
            maxSpeed = 0.62;
        } else if (state.getAirTicks() > 10) {
            // Air resistance decay
            maxSpeed = 0.36;
        }

        // Account for Speed effect (+20% speed per level)
        MobEffectInstance speedEffect = player.getEffect(MobEffects.SPEED);
        if (speedEffect != null) {
            int amplifier = speedEffect.getAmplifier() + 1;
            maxSpeed *= (1.0 + (0.20 * amplifier));
        }

        double buffer = getConfig().getDouble("horizontalBuffer", 0.08);
        double threshold = maxSpeed + buffer;

        if (deltaXZ > threshold) {
            double excess = deltaXZ - maxSpeed;
            double confidence = Math.min(1.0, 0.70 + (excess / maxSpeed));
            flag(data, getConfig().violationWeight, confidence,
                    String.format("speed=%.3f, max=%.3f, airTicks=%d, diff=+%.3f",
                            deltaXZ, maxSpeed, state.getAirTicks(), excess));
        }
    }
}
