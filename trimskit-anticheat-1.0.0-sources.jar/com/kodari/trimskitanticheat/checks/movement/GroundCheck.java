package com.kodari.trimskitanticheat.checks.movement;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.movement.MovementState;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Validates client onGround assertions against server-authoritative collision queries.
 * Detects spoofed ground states used for critical hits, no-fall, or packet manipulation.
 */
public class GroundCheck extends Check {

    public GroundCheck() {
        super("movement_ground", "Ground", "Detects spoofed onGround states and ground discrepancies.", CheckCategory.MOVEMENT);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromMovement(data, player)) {
            return;
        }

        MovementState state = data.getMovementState();
        boolean clientGround = state.isClientOnGround();
        boolean serverGround = state.isServerOnGround();

        // Case 1: Client claims onGround while in open air
        if (clientGround && !serverGround && state.getAirTicks() > 3) {
            flag(data, getConfig().violationWeight, 0.90,
                    String.format("clientGround=true, serverGround=false, airTicks=%d, deltaY=%.3f",
                            state.getAirTicks(), state.getDeltaY()));
        }

        // Case 2: Client claims in air while continuously on solid ground (Criticals / NoGround cheat)
        if (!clientGround && serverGround && state.getGroundTicks() > 15 && Math.abs(state.getDeltaY()) < 0.001) {
            flag(data, getConfig().violationWeight * 0.75, 0.85,
                    String.format("clientGround=false, serverGround=true, groundTicks=%d", state.getGroundTicks()));
        }
    }
}
