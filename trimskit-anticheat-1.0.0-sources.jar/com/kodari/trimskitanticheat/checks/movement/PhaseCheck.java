package com.kodari.trimskitanticheat.checks.movement;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.util.CollisionUtil;
import net.minecraft.server.level.ServerPlayer;

/**
 * Validates player collision against solid world geometry, preventing noclip and phase exploits.
 */
public class PhaseCheck extends Check {

    public PhaseCheck() {
        super("movement_phase", "Phase", "Detects movement through impassable solid blocks.", CheckCategory.MOVEMENT);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromMovement(data, player)) {
            return;
        }

        if (CollisionUtil.isCollidingWithSolid(player.level(), player.getBoundingBox())) {
            flag(data, getConfig().violationWeight, 0.95,
                    String.format("colliding with solid at pos=[%.2f, %.2f, %.2f]",
                            player.getX(), player.getY(), player.getZ()));
        }
    }
}
