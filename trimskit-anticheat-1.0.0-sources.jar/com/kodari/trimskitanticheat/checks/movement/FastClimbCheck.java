package com.kodari.trimskitanticheat.checks.movement;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.movement.MovementState;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.util.CollisionUtil;
import net.minecraft.server.level.ServerPlayer;

/**
 * Validates climbing speed on ladders, vines, and scaffolding.
 */
public class FastClimbCheck extends Check {

    public FastClimbCheck() {
        super("movement_fastclimb", "FastClimb", "Detects climbing speed exceeding physical ladder/vine limits.", CheckCategory.MOVEMENT);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromMovement(data, player)) {
            return;
        }

        MovementState state = data.getMovementState();
        if (CollisionUtil.isNearClimbable(player.level(), player.getBoundingBox())) {
            double deltaY = state.getDeltaY();
            double maxClimb = getConfig().getDouble("maxClimbSpeed", 0.22);

            if (deltaY > maxClimb) {
                flag(data, getConfig().violationWeight, 0.85,
                        String.format("climb deltaY=%.3f > max=%.2f", deltaY, maxClimb));
            }
        }
    }
}
