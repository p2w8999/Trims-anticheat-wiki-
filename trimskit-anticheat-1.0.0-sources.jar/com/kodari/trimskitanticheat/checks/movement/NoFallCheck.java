package com.kodari.trimskitanticheat.checks.movement;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.movement.MovementState;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Validates falling kinetics and detects attempts to negate fall damage through packet spoofing.
 */
public class NoFallCheck extends Check {

    public NoFallCheck() {
        super("movement_nofall", "NoFall", "Detects client attempts to negate fall damage via ground spoofing.", CheckCategory.MOVEMENT);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromMovement(data, player) || ExemptionManager.isInFluids(player)) {
            return;
        }

        MovementState state = data.getMovementState();
        double minFall = getConfig().getDouble("minFallDistance", 3.0);

        // Client claiming onGround prematurely during high fall without contacting ground
        if (state.isClientOnGround() && !state.isServerOnGround() && state.getServerFallDistance() > minFall) {
            flag(data, getConfig().violationWeight, 0.95,
                    String.format("spoofed ground with fallDistance=%.2f, deltaY=%.3f",
                            state.getServerFallDistance(), state.getDeltaY()));
        }
    }
}
