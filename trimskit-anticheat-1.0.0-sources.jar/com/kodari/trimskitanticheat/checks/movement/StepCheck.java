package com.kodari.trimskitanticheat.checks.movement;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.movement.MovementState;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;

/**
 * Detects unnatural step heights and instant vertical step-assist modifications.
 */
public class StepCheck extends Check {

    public StepCheck() {
        super("movement_step", "Step", "Detects impossible instantaneous vertical displacement without jumping.", CheckCategory.MOVEMENT);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromMovement(data, player)) {
            return;
        }

        MovementState state = data.getMovementState();
        double deltaY = state.getDeltaY();
        double maxStep = getConfig().getDouble("maxStepHeight", 0.60);

        // Instant vertical displacement while claiming ground
        if (state.isClientOnGround() && deltaY > maxStep) {
            if (player.hasEffect(MobEffects.JUMP_BOOST)) {
                return;
            }
            flag(data, getConfig().violationWeight, 0.90,
                    String.format("instant step deltaY=%.3f > max=%.2f", deltaY, maxStep));
        }
    }
}
