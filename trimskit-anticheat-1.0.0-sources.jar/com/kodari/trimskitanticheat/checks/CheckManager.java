package com.kodari.trimskitanticheat.checks;

import com.kodari.trimskitanticheat.checks.combat.*;
import com.kodari.trimskitanticheat.checks.movement.*;
import com.kodari.trimskitanticheat.checks.player.*;
import com.kodari.trimskitanticheat.checks.protocol.*;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.util.CollisionUtil;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central registry and dispatcher for all detection checks.
 */
public class CheckManager {

    private final Map<String, Check> checks = new ConcurrentHashMap<>();

    // Movement checks
    public final SpeedCheck speedCheck = new SpeedCheck();
    public final FlyCheck flyCheck = new FlyCheck();
    public final GroundCheck groundCheck = new GroundCheck();
    public final NoFallCheck noFallCheck = new NoFallCheck();
    public final StepCheck stepCheck = new StepCheck();
    public final FastClimbCheck fastClimbCheck = new FastClimbCheck();
    public final PhaseCheck phaseCheck = new PhaseCheck();

    // Combat checks
    public final ReachCheck reachCheck = new ReachCheck();
    public final HitboxCheck hitboxCheck = new HitboxCheck();
    public final AngleCheck angleCheck = new AngleCheck();
    public final AttackRateCheck attackRateCheck = new AttackRateCheck();
    public final AimConsistencyCheck aimConsistencyCheck = new AimConsistencyCheck();

    // Protocol & Player checks
    public final TimerCheck timerCheck = new TimerCheck();
    public final InvalidRotationCheck invalidRotationCheck = new InvalidRotationCheck();
    public final FastUseCheck fastUseCheck = new FastUseCheck();
    public final InvalidActionCheck invalidActionCheck = new InvalidActionCheck();

    public CheckManager() {
        register(speedCheck);
        register(flyCheck);
        register(groundCheck);
        register(noFallCheck);
        register(stepCheck);
        register(fastClimbCheck);
        register(phaseCheck);

        register(reachCheck);
        register(hitboxCheck);
        register(angleCheck);
        register(attackRateCheck);
        register(aimConsistencyCheck);

        register(timerCheck);
        register(invalidRotationCheck);
        register(fastUseCheck);
        register(invalidActionCheck);
    }

    private void register(Check check) {
        checks.put(check.getId(), check);
    }

    public Check getCheck(String id) {
        return checks.get(id);
    }

    public Collection<Check> getAllChecks() {
        return checks.values();
    }

    /**
     * Dispatches packet and environmental analysis for an incoming movement packet.
     */
    public void processMovement(PlayerData data, ServerPlayer player, ServerboundMovePlayerPacket packet) {
        double newX = packet.getX(player.getX());
        double newY = packet.getY(player.getY());
        double newZ = packet.getZ(player.getZ());
        float newYaw = packet.getYRot(player.getYRot());
        float newPitch = packet.getXRot(player.getXRot());

        // Validate rotation finite properties
        if (packet.hasRotation()) {
            if (!invalidRotationCheck.check(data, newYaw, newPitch)) {
                return;
            }
        }

        // Protocol Timer check
        timerCheck.check(data, player);

        // Update server ground calculation
        boolean clientGround = packet.isOnGround();
        boolean serverGround = CollisionUtil.isOnGround(player.level(), player.getBoundingBox(), 0.05);

        // Update kinematic state
        Vec3 newPos = new Vec3(newX, newY, newZ);
        data.getMovementState().update(newPos, newYaw, newPitch, clientGround, serverGround);

        // Update aim samples
        if (packet.hasRotation()) {
            data.getRotationHistory().addSample(
                    newYaw,
                    newPitch,
                    data.getMovementState().getDeltaYaw(),
                    data.getMovementState().getDeltaPitch()
            );
        }

        // Run movement checks
        if (packet.hasPosition()) {
            speedCheck.check(data, player);
            flyCheck.check(data, player);
            groundCheck.check(data, player);
            noFallCheck.check(data, player);
            stepCheck.check(data, player);
            fastClimbCheck.check(data, player);
            phaseCheck.check(data, player);
        }
    }

    /**
     * Dispatches combat analysis for an incoming attack packet.
     * Returns true if the attack is legitimate, or false if it should be rejected.
     */
    public boolean processAttack(PlayerData data, ServerPlayer player, ServerboundAttackPacket packet) {
        if (!invalidActionCheck.check(data, player)) {
            return false;
        }

        // Check attack rate
        if (!attackRateCheck.check(data, player)) {
            return false;
        }

        Entity target = player.level().getEntityOrPart(packet.entityId());
        if (target == null) {
            return true;
        }

        // Aim consistency check
        aimConsistencyCheck.check(data, player);

        // Angle check
        if (!angleCheck.check(data, player, target)) {
            return false;
        }

        // Hitbox check
        if (!hitboxCheck.check(data, player, target)) {
            return false;
        }

        // Reach check
        if (!reachCheck.check(data, player, target)) {
            return false;
        }

        return true;
    }
}
