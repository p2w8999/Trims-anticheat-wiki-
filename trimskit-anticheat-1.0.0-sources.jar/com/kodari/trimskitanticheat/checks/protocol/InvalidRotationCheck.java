package com.kodari.trimskitanticheat.checks.protocol;

import com.kodari.trimskitanticheat.aim.AimAnalysis;
import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.util.MathUtil;

/**
 * Validates protocol rotation packets against NaN, Infinity, and impossible pitch angles.
 */
public class InvalidRotationCheck extends Check {

    public InvalidRotationCheck() {
        super("protocol_rotation", "InvalidRotation", "Detects NaN, Infinity, and out-of-bounds head rotations.", CheckCategory.PROTOCOL);
    }

    public boolean check(PlayerData data, float yaw, float pitch) {
        if (!isEnabled()) {
            return true;
        }

        if (!MathUtil.isFinite(yaw) || !MathUtil.isFinite(pitch)) {
            flag(data, getConfig().violationWeight, 1.0,
                    String.format("non-finite rotation yaw=%f, pitch=%f", yaw, pitch));
            return false;
        }

        if (!AimAnalysis.isPitchLegal(pitch)) {
            flag(data, getConfig().violationWeight, 1.0,
                    String.format("impossible pitch=%.2f (must be between -90 and 90)", pitch));
            return false;
        }

        return true;
    }
}
