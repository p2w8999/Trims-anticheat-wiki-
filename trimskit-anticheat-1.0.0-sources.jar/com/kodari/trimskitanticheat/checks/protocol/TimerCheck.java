package com.kodari.trimskitanticheat.checks.protocol;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.ExemptionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Detects client-side clock acceleration (Timer cheats) and packet bursts.
 */
public class TimerCheck extends Check {

    public TimerCheck() {
        super("protocol_timer", "Timer", "Detects client game clock acceleration and packet flood.", CheckCategory.PROTOCOL);
    }

    public void check(PlayerData data, ServerPlayer player) {
        if (!isEnabled() || ExemptionManager.isExemptFromMovement(data, player)) {
            return;
        }

        int rate = data.getPacketThrottler().recordPacketAndGetRate();
        double maxRate = getConfig().getDouble("maxPacketsPerSecond", 23.0);

        if (rate > maxRate) {
            double confidence = Math.min(1.0, 0.70 + ((rate - maxRate) * 0.05));
            flag(data, getConfig().violationWeight, confidence,
                    String.format("packetRate=%d/s > max=%.0f/s", rate, maxRate));
        }
    }
}
