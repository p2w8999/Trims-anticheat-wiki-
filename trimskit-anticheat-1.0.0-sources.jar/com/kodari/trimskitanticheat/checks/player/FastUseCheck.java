package com.kodari.trimskitanticheat.checks.player;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Validates the duration of item consumption actions (food, potions) to prevent FastUse cheats.
 */
public class FastUseCheck extends Check {

    public FastUseCheck() {
        super("player_fastuse", "FastUse", "Detects instant or accelerated item consumption.", CheckCategory.PLAYER);
    }

    public void check(PlayerData data, ServerPlayer player, ItemStack item, int usedTicks) {
        if (!isEnabled()) {
            return;
        }

        double minTicks = getConfig().getDouble("minEatTicks", 28.0);
        if (usedTicks < minTicks && !item.isEmpty()) {
            double confidence = Math.min(1.0, 0.80 + ((minTicks - usedTicks) / minTicks));
            flag(data, getConfig().violationWeight, confidence,
                    String.format("consumed item %s in %d ticks < min=%.0f ticks",
                            item.getItem().toString(), usedTicks, minTicks));
        }
    }
}
