package com.kodari.trimskitanticheat.checks.player;

import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.checks.CheckCategory;
import com.kodari.trimskitanticheat.player.PlayerData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Validates player physical posture and interaction states, detecting conflicting actions
 * such as sprinting while sneaking, interacting while dead, or impossible actions.
 */
public class InvalidActionCheck extends Check {

    public InvalidActionCheck() {
        super("player_invalidaction", "InvalidAction", "Detects conflicting, dead, or impossible player action states.", CheckCategory.PLAYER);
    }

    public boolean check(PlayerData data, ServerPlayer player) {
        if (!isEnabled()) {
            return true;
        }

        if (player.isDeadOrDying()) {
            flag(data, getConfig().violationWeight, 1.0, "action attempted while dead or dying");
            return false;
        }

        if (player.isSprinting() && player.isShiftKeyDown()) {
            flag(data, getConfig().violationWeight, 0.90, "sprinting while sneaking");
            return false;
        }

        return true;
    }
}
