package com.kodari.trimskitanticheat.checks;

/**
 * High-level categorization of security checks.
 */
public enum CheckCategory {
    MOVEMENT,
    COMBAT,
    PLAYER,
    PROTOCOL
}
