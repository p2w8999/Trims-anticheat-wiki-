package com.kodari.trimskitanticheat.combat;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Historical snapshot of an entity's spatial position and bounding box for latency compensation.
 */
public record HistoricalEntityPosition(int entityId, AABB boundingBox, Vec3 position, long timestampMs, long tick) {
}
