package com.kodari.trimskitanticheat.combat;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks historical entity locations for server-side lag compensation and reach validation.
 * Memory bounded with automatic pruning of snapshots older than 1000ms.
 */
public class CombatTracker {

    private static final long MAX_HISTORY_AGE_MS = 1000L;
    private final Map<Integer, Deque<HistoricalEntityPosition>> entityHistory = new ConcurrentHashMap<>();
    private final Deque<Long> attackTimestamps = new ArrayDeque<>(64);

    /**
     * Records the position of an entity at the current moment.
     */
    public void recordEntityPosition(Entity entity, long serverTick) {
        if (entity == null) return;

        int id = entity.getId();
        long now = System.currentTimeMillis();
        HistoricalEntityPosition snapshot = new HistoricalEntityPosition(
                id,
                entity.getBoundingBox(),
                entity.position(),
                now,
                serverTick
        );

        entityHistory.compute(id, (k, deque) -> {
            if (deque == null) {
                deque = new ArrayDeque<>();
            }
            deque.addLast(snapshot);

            // Prune snapshots older than MAX_HISTORY_AGE_MS
            long cutoff = now - MAX_HISTORY_AGE_MS;
            while (!deque.isEmpty() && deque.peekFirst().timestampMs() < cutoff) {
                deque.pollFirst();
            }
            return deque;
        });
    }

    /**
     * Finds the closest historical bounding box corresponding to a given target timestamp.
     * Used for server-authoritative latency compensation.
     */
    public AABB findHistoricalBox(int entityId, long targetTimestamp, AABB currentBox) {
        Deque<HistoricalEntityPosition> deque = entityHistory.get(entityId);
        if (deque == null || deque.isEmpty()) {
            return currentBox;
        }

        synchronized (deque) {
            HistoricalEntityPosition closest = null;
            long minDiff = Long.MAX_VALUE;

            for (HistoricalEntityPosition pos : deque) {
                long diff = Math.abs(pos.timestampMs() - targetTimestamp);
                if (diff < minDiff) {
                    minDiff = diff;
                    closest = pos;
                }
            }

            return closest != null ? closest.boundingBox() : currentBox;
        }
    }

    /**
     * Records an attack click and returns current estimated CPS over the last 1 second window.
     */
    public synchronized int recordAttackAndGetCPS() {
        long now = System.currentTimeMillis();
        attackTimestamps.addLast(now);

        long windowStart = now - 1000L;
        while (!attackTimestamps.isEmpty() && attackTimestamps.peekFirst() < windowStart) {
            attackTimestamps.pollFirst();
        }

        return attackTimestamps.size();
    }

    /**
     * Cleanup entity history for removed entities.
     */
    public void removeEntity(int entityId) {
        entityHistory.remove(entityId);
    }

    public void clear() {
        entityHistory.clear();
        synchronized (this) {
            attackTimestamps.clear();
        }
    }
}
