package com.kodari.trimskitanticheat.combat;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Detailed telemetry record of a single combat attack event.
 */
public record AttackRecord(
        int targetEntityId,
        Vec3 attackerEyePos,
        Vec3 attackerLookVec,
        AABB targetBoundingBox,
        double measuredDistance,
        long timestampMs,
        long serverTick
) {
}
