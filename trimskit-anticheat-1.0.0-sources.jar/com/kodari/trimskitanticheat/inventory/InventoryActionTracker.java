package com.kodari.trimskitanticheat.inventory;

/**
 * Tracks inventory and container interactions to prevent impossible rapid-transfer or movement exploits.
 */
public class InventoryActionTracker {

    private long lastInventoryOpenTimeMs;
    private long lastSlotClickTimeMs;
    private int clicksInCurrentSecond;
    private long currentSecondEpoch;

    public void recordOpen() {
        this.lastInventoryOpenTimeMs = System.currentTimeMillis();
    }

    public synchronized void recordClick() {
        long now = System.currentTimeMillis();
        this.lastSlotClickTimeMs = now;

        long currentSecond = now / 1000L;
        if (currentSecond != currentSecondEpoch) {
            currentSecondEpoch = currentSecond;
            clicksInCurrentSecond = 1;
        } else {
            clicksInCurrentSecond++;
        }
    }

    public long getLastInventoryOpenTimeMs() {
        return lastInventoryOpenTimeMs;
    }

    public long getLastSlotClickTimeMs() {
        return lastSlotClickTimeMs;
    }

    public synchronized int getClicksInCurrentSecond() {
        return clicksInCurrentSecond;
    }
}
