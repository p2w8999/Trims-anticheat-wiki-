package com.kodari.trimskitanticheat.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.kodari.trimskitanticheat.TrimskitAntiCheat;
import com.kodari.trimskitanticheat.checks.Check;
import com.kodari.trimskitanticheat.permissions.PermissionManager;
import com.kodari.trimskitanticheat.player.PlayerData;
import com.kodari.trimskitanticheat.violations.Violation;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;
import java.util.Map;

/**
 * Implements the administrative command suite for Trimskit AntiCheat (/tac).
 */
public class TrimskitCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("tac")
                        .requires(PermissionManager::hasStaffPermission)
                        .then(Commands.literal("status").executes(TrimskitCommand::executeStatus))
                        .then(Commands.literal("alerts").executes(TrimskitCommand::executeAlerts))
                        .then(Commands.literal("version").executes(TrimskitCommand::executeVersion))
                        .then(Commands.literal("reload").executes(TrimskitCommand::executeReload))
                        .then(Commands.literal("checks").executes(TrimskitCommand::executeChecks))
                        .then(Commands.literal("violations")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(TrimskitCommand::executeViolations)))
                        .then(Commands.literal("inspect")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(TrimskitCommand::executeInspect)))
                        .then(Commands.literal("debug")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(TrimskitCommand::executeDebug)))
                        .then(Commands.literal("check")
                                .then(Commands.argument("check_id", StringArgumentType.word())
                                        .then(Commands.literal("enable")
                                                .executes(ctx -> executeToggleCheck(ctx, true)))
                                        .then(Commands.literal("disable")
                                                .executes(ctx -> executeToggleCheck(ctx, false)))))
        );
    }

    private static int executeStatus(CommandContext<CommandSourceStack> context) {
        int trackedPlayers = TrimskitAntiCheat.getInstance().getPlayerDataManager().getAllPlayers().size();
        int totalChecks = TrimskitAntiCheat.getInstance().getCheckManager().getAllChecks().size();

        MutableComponent comp = Component.literal("§8=== §cTrimskit AntiCheat Status §8===\n")
                .append(Component.literal("§7Target Version: §fMinecraft 26.2 (Fabric / Java 25)\n"))
                .append(Component.literal("§7Tracked Sessions: §a" + trackedPlayers + "\n"))
                .append(Component.literal("§7Registered Checks: §a" + totalChecks + "\n"))
                .append(Component.literal("§7Staff Alerts: §a" +
                        (TrimskitAntiCheat.getInstance().getConfigManager().getConfig().system.staffAlertsEnabled ? "Enabled" : "Disabled")));

        context.getSource().sendSuccess(() -> comp, false);
        return 1;
    }

    private static int executeAlerts(CommandContext<CommandSourceStack> context) {
        if (!context.getSource().isPlayer()) {
            context.getSource().sendFailure(Component.literal("Only in-game players can toggle personal alerts."));
            return 0;
        }

        ServerPlayer player = context.getSource().getPlayer();
        PlayerData data = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(player);
        if (data != null) {
            boolean current = data.isStaffAlertsEnabled();
            data.setStaffAlertsEnabled(!current);
            boolean updated = data.isStaffAlertsEnabled();
            context.getSource().sendSuccess(() ->
                    Component.literal("§8[§cTrimskit§8] §fStaff alerts are now: " + (updated ? "§aEnabled" : "§cDisabled")), false);
        }
        return 1;
    }

    private static int executeViolations(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer target = EntityArgument.getPlayer(context, "player");
        PlayerData data = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(target);

        if (data == null) {
            context.getSource().sendFailure(Component.literal("No tracking data available for " + target.getScoreboardName()));
            return 0;
        }

        MutableComponent comp = Component.literal("§8=== §cViolations: §f" + target.getScoreboardName() + " §8===\n");
        Map<String, Double> vls = data.getViolationLevels();
        boolean hasViolations = false;

        for (Map.Entry<String, Double> entry : vls.entrySet()) {
            if (entry.getValue() > 0.1) {
                hasViolations = true;
                comp.append(Component.literal("§7• §e" + entry.getKey() + ": §c" + String.format("%.1f", entry.getValue()) + "\n"));
            }
        }

        if (!hasViolations) {
            comp.append(Component.literal("§aNo active violations recorded. Clean session.\n"));
        }

        context.getSource().sendSuccess(() -> comp, false);
        return 1;
    }

    private static int executeInspect(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer target = EntityArgument.getPlayer(context, "player");
        PlayerData data = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(target);

        if (data == null) {
            context.getSource().sendFailure(Component.literal("No tracking data available for " + target.getScoreboardName()));
            return 0;
        }

        MutableComponent comp = Component.literal("§8=== §cInspect: §f" + target.getScoreboardName() + " §8===\n")
                .append(Component.literal(String.format("§7Ping: §f%dms §8| §7AirTicks: §f%d §8| §7Ground: §f%s\n",
                        data.getLatencyPingMs(),
                        data.getMovementState().getAirTicks(),
                        data.getMovementState().isServerOnGround() ? "§aYes" : "§cNo")))
                .append(Component.literal(String.format("§7Position: §f[%.2f, %.2f, %.2f] §8| §7FallDist: §f%.2f\n",
                        target.getX(), target.getY(), target.getZ(),
                        data.getMovementState().getServerFallDistance())))
                .append(Component.literal("§7Recent Flags:\n"));

        Violation[] history = data.getViolationHistory();
        if (history.length == 0) {
            comp.append(Component.literal("§a  None.\n"));
        } else {
            int count = Math.min(5, history.length);
            for (int i = history.length - count; i < history.length; i++) {
                Violation v = history[i];
                comp.append(Component.literal(String.format("§7  • §e%s §7(VL: §c%.1f§7): §f%s\n",
                        v.checkName(), v.violationLevel(), v.evidence())));
            }
        }

        context.getSource().sendSuccess(() -> comp, false);
        return 1;
    }

    private static int executeChecks(CommandContext<CommandSourceStack> context) {
        Collection<Check> checks = TrimskitAntiCheat.getInstance().getCheckManager().getAllChecks();
        MutableComponent comp = Component.literal("§8=== §cTrimskit Checks (" + checks.size() + ") §8===\n");

        for (Check check : checks) {
            comp.append(Component.literal("§7• §e" + check.getId() + " §7[" + check.getCategory() + "]: " +
                    (check.isEnabled() ? "§aENABLED" : "§cDISABLED") + "\n"));
        }

        context.getSource().sendSuccess(() -> comp, false);
        return 1;
    }

    private static int executeToggleCheck(CommandContext<CommandSourceStack> context, boolean enable) {
        String checkId = StringArgumentType.getString(context, "check_id");
        Check check = TrimskitAntiCheat.getInstance().getCheckManager().getCheck(checkId);

        if (check == null) {
            context.getSource().sendFailure(Component.literal("Unknown check ID: " + checkId));
            return 0;
        }

        check.setEnabled(enable);
        context.getSource().sendSuccess(() ->
                Component.literal("§8[§cTrimskit§8] §fCheck §e" + checkId + " §fis now " +
                        (enable ? "§aENABLED" : "§cDISABLED")), true);
        return 1;
    }

    private static int executeDebug(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer target = EntityArgument.getPlayer(context, "player");
        PlayerData data = TrimskitAntiCheat.getInstance().getPlayerDataManager().getPlayerData(target);

        if (data == null) {
            context.getSource().sendFailure(Component.literal("Player not found in active sessions."));
            return 0;
        }

        boolean debug = !data.isDebugMode();
        data.setDebugMode(debug);

        context.getSource().sendSuccess(() ->
                Component.literal("§8[§cTrimskit§8] §fDebug mode for §e" + target.getScoreboardName() + " §fis now: " +
                        (debug ? "§aON" : "§cOFF")), true);
        return 1;
    }

    private static int executeReload(CommandContext<CommandSourceStack> context) {
        TrimskitAntiCheat.getInstance().getConfigManager().load();
        context.getSource().sendSuccess(() ->
                Component.literal("§8[§cTrimskit§8] §aConfiguration reloaded successfully."), true);
        return 1;
    }

    private static int executeVersion(CommandContext<CommandSourceStack> context) {
        context.getSource().sendSuccess(() ->
                Component.literal("§8[§cTrimskit§8] §fTrimskit AntiCheat §av1.0.0 §7(Minecraft 26.2, Fabric, Java 25)"), false);
        return 1;
    }
}
