package com.kodari.trimskitanticheat.config;

/**
 * System-level operational configuration.
 */
public class SystemConfig {
    public boolean debugMode = false;
    public boolean logAlertsToConsole = true;
    public boolean staffAlertsEnabled = true;
    public long alertCooldownMs = 1000L;
    public int minStaffPermissionLevel = 2;
    public int maxStoredViolationsPerPlayer = 100;
}
