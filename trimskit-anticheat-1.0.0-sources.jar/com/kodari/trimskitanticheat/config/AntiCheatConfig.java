package com.kodari.trimskitanticheat.config;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Top-level configuration object for Trimskit AntiCheat.
 */
public class AntiCheatConfig {
    public SystemConfig system = new SystemConfig();
    public DecayConfig decay = new DecayConfig();
    public PunishmentConfig punishment = new PunishmentConfig();
    public Map<String, CheckConfig> checks = new ConcurrentHashMap<>();

    public CheckConfig getCheckConfig(String checkId) {
        return checks.computeIfAbsent(checkId, k -> new CheckConfig());
    }
}
