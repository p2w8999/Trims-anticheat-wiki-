package com.kodari.trimskitanticheat.config;

/**
 * Configuration for violation decay over time.
 */
public class DecayConfig {
    public int decayIntervalTicks = 20;
    public double decayAmountPerInterval = 0.5;
    public double exponentialDecayFactor = 0.05;
}
