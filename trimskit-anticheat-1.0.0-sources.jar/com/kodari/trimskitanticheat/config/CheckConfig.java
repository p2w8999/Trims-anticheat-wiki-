package com.kodari.trimskitanticheat.config;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration options for an individual detection check.
 */
public class CheckConfig {
    public boolean enabled = true;
    public double maxViolationLevel = 25.0;
    public double violationWeight = 1.0;
    public Map<String, Double> customParameters = new HashMap<>();

    public CheckConfig() {
    }

    public CheckConfig(boolean enabled, double maxViolationLevel, double violationWeight) {
        this.enabled = enabled;
        this.maxViolationLevel = maxViolationLevel;
        this.violationWeight = violationWeight;
    }

    public double getDouble(String key, double defaultValue) {
        return customParameters.getOrDefault(key, defaultValue);
    }

    public void setDouble(String key, double value) {
        customParameters.put(key, value);
    }
}
