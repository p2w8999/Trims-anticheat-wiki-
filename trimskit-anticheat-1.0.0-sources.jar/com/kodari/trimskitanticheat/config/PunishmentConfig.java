package com.kodari.trimskitanticheat.config;

/**
 * Configuration for automated punishments when violation levels exceed thresholds.
 */
public class PunishmentConfig {
    public boolean enabled = false;
    public double kickThreshold = 50.0;
    public double banThreshold = 100.0;
    public String kickMessage = "§c[Trimskit] Disconnected for gameplay inconsistencies.";
    public String banCommand = "ban %player% 7d [Trimskit] Suspicious combat or movement modifications.";
}
