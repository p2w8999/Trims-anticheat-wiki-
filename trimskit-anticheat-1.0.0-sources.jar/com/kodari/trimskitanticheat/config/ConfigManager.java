package com.kodari.trimskitanticheat.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kodari.trimskitanticheat.TrimskitAntiCheat;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

/**
 * Manages configuration persistence, default template generation, and runtime reloading.
 */
public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path configPath;
    private AntiCheatConfig currentConfig;

    public ConfigManager(Path configDir) {
        this.configPath = configDir.resolve("trimskit.json");
        this.currentConfig = new AntiCheatConfig();
    }

    public synchronized void load() {
        File file = configPath.toFile();
        if (!file.exists()) {
            TrimskitAntiCheat.LOGGER.info("Configuration file not found. Generating default configuration at: {}", configPath);
            populateDefaults(currentConfig);
            save();
            return;
        }

        try (FileReader reader = new FileReader(file)) {
            AntiCheatConfig loaded = GSON.fromJson(reader, AntiCheatConfig.class);
            if (loaded != null) {
                // Ensure default checks are present if new checks were added
                populateDefaults(loaded);
                this.currentConfig = loaded;
                TrimskitAntiCheat.LOGGER.info("Trimskit AntiCheat configuration successfully loaded.");
            } else {
                TrimskitAntiCheat.LOGGER.warn("Loaded configuration was null. Falling back to in-memory defaults.");
            }
        } catch (Exception e) {
            TrimskitAntiCheat.LOGGER.error("Failed to parse configuration file '{}': {}. Preserving current active configuration.",
                    configPath, e.getMessage());
        }
    }

    public synchronized void save() {
        File file = configPath.toFile();
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (FileWriter writer = new FileWriter(file)) {
            GSON.toJson(currentConfig, writer);
        } catch (IOException e) {
            TrimskitAntiCheat.LOGGER.error("Could not write configuration to '{}': {}", configPath, e.getMessage());
        }
    }

    private void populateDefaults(AntiCheatConfig config) {
        // Movement
        addDefaultCheck(config, "movement_speed", 30.0, 1.0, "horizontalBuffer", 0.08, "sprintMultiplier", 1.35);
        addDefaultCheck(config, "movement_fly", 25.0, 1.5, "maxAirTicks", 25.0, "minVerticalFallRate", -0.08);
        addDefaultCheck(config, "movement_ground", 20.0, 1.0, "groundTolerance", 0.001);
        addDefaultCheck(config, "movement_nofall", 20.0, 1.5, "minFallDistance", 3.0);
        addDefaultCheck(config, "movement_step", 20.0, 1.0, "maxStepHeight", 0.6);
        addDefaultCheck(config, "movement_fastclimb", 15.0, 1.0, "maxClimbSpeed", 0.2);
        addDefaultCheck(config, "movement_phase", 35.0, 2.0, "maxPenetrationDepth", 0.15);

        // Combat
        addDefaultCheck(config, "combat_reach", 40.0, 1.5, "maxSurvivalReach", 3.05, "maxCreativeReach", 5.0, "lagCompensationMs", 400.0);
        addDefaultCheck(config, "combat_hitbox", 30.0, 1.5, "boxExpansion", 0.1);
        addDefaultCheck(config, "combat_angle", 25.0, 1.0, "maxAngleDegrees", 95.0);
        addDefaultCheck(config, "combat_attackrate", 20.0, 1.0, "maxClicksPerSecond", 22.0);
        addDefaultCheck(config, "combat_aimconsistency", 30.0, 1.0, "minSampleCount", 20.0, "gcdVarianceTolerance", 0.0001);

        // Protocol & Player
        addDefaultCheck(config, "protocol_timer", 30.0, 1.5, "maxPacketsPerSecond", 23.0, "sampleWindowTicks", 40.0);
        addDefaultCheck(config, "protocol_rotation", 15.0, 2.0);
        addDefaultCheck(config, "player_fastuse", 20.0, 1.0, "minEatTicks", 28.0);
    }

    private void addDefaultCheck(AntiCheatConfig config, String id, double maxVL, double weight, Object... params) {
        if (!config.checks.containsKey(id)) {
            CheckConfig checkConfig = new CheckConfig(true, maxVL, weight);
            for (int i = 0; i < params.length; i += 2) {
                if (i + 1 < params.length) {
                    checkConfig.setDouble((String) params[i], ((Number) params[i + 1]).doubleValue());
                }
            }
            config.checks.put(id, checkConfig);
        }
    }

    public AntiCheatConfig getConfig() {
        return currentConfig;
    }
}
