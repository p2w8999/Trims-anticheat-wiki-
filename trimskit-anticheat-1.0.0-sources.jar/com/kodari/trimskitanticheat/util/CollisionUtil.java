package com.kodari.trimskitanticheat.util;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Server-side collision query utilities to verify environmental interactions,
 * block tags, and physical materials without client trust.
 */
public final class CollisionUtil {

    private CollisionUtil() {
    }

    /**
     * Checks if the given AABB is currently in contact with solid ground or blocks below it.
     */
    public static boolean isOnGround(Level level, AABB box, double verticalTolerance) {
        AABB groundBox = box.expandTowards(0, -verticalTolerance, 0);
        int minX = (int) Math.floor(groundBox.minX);
        int maxX = (int) Math.floor(groundBox.maxX);
        int minY = (int) Math.floor(groundBox.minY);
        int maxY = (int) Math.floor(box.minY);
        int minZ = (int) Math.floor(groundBox.minZ);
        int maxZ = (int) Math.floor(groundBox.maxZ);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (!state.isAir() && state.isSolid()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Checks if the player is intersecting with or adjacent to climbable blocks (ladders, vines, scaffolding).
     */
    public static boolean isNearClimbable(Level level, AABB box) {
        AABB expanded = box.inflate(0.1, 0.05, 0.1);
        int minX = (int) Math.floor(expanded.minX);
        int maxX = (int) Math.floor(expanded.maxX);
        int minY = (int) Math.floor(expanded.minY);
        int maxY = (int) Math.floor(expanded.maxY);
        int minZ = (int) Math.floor(expanded.minZ);
        int maxZ = (int) Math.floor(expanded.maxZ);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.is(BlockTags.CLIMBABLE) || state.is(Blocks.SCAFFOLDING)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Checks if the player is in or touching ice blocks (which heavily alters friction).
     */
    public static boolean isNearIce(Level level, AABB box) {
        AABB expanded = box.expandTowards(0, -0.5, 0).inflate(0.1, 0, 0.1);
        int minX = (int) Math.floor(expanded.minX);
        int maxX = (int) Math.floor(expanded.maxX);
        int minY = (int) Math.floor(expanded.minY);
        int maxY = (int) Math.floor(expanded.maxY);
        int minZ = (int) Math.floor(expanded.minZ);
        int maxZ = (int) Math.floor(expanded.maxZ);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.is(BlockTags.ICE)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Checks if the player is in or touching slime or honey blocks (bouncing/sticking).
     */
    public static boolean isNearSlimeOrHoney(Level level, AABB box) {
        AABB expanded = box.expandTowards(0, -0.5, 0).inflate(0.1, 0, 0.1);
        int minX = (int) Math.floor(expanded.minX);
        int maxX = (int) Math.floor(expanded.maxX);
        int minY = (int) Math.floor(expanded.minY);
        int maxY = (int) Math.floor(expanded.maxY);
        int minZ = (int) Math.floor(expanded.minZ);
        int maxZ = (int) Math.floor(expanded.maxZ);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.is(Blocks.SLIME_BLOCK) || state.is(Blocks.HONEY_BLOCK)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Checks if the player is standing inside web or powder snow.
     */
    public static boolean isInWebOrPowderSnow(Level level, AABB box) {
        int minX = (int) Math.floor(box.minX);
        int maxX = (int) Math.floor(box.maxX);
        int minY = (int) Math.floor(box.minY);
        int maxY = (int) Math.floor(box.maxY);
        int minZ = (int) Math.floor(box.minZ);
        int maxZ = (int) Math.floor(box.maxZ);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.is(Blocks.COBWEB) || state.is(Blocks.POWDER_SNOW)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Checks if a player's bounding box is substantially colliding with a solid block (Phase check).
     */
    public static boolean isCollidingWithSolid(Level level, AABB box) {
        // Contract slightly to avoid false positives at edges
        AABB contracted = box.deflate(0.05);
        int minX = (int) Math.floor(contracted.minX);
        int maxX = (int) Math.floor(contracted.maxX);
        int minY = (int) Math.floor(contracted.minY);
        int maxY = (int) Math.floor(contracted.maxY);
        int minZ = (int) Math.floor(contracted.minZ);
        int maxZ = (int) Math.floor(contracted.maxZ);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (!state.isAir() && state.isSolid() && state.blocksMotion()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
