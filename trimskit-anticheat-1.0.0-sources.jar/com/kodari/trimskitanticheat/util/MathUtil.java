package com.kodari.trimskitanticheat.util;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * High-performance mathematical utilities for vector arithmetic, bounding box calculations,
 * ray-box intersections, and rotation delta analysis.
 */
public final class MathUtil {

    private MathUtil() {
        // Utility class
    }

    /**
     * Clamps a double value between min and max.
     */
    public static double clamp(double value, double min, double max) {
        if (value < min) return min;
        return Math.min(value, max);
    }

    /**
     * Calculates the horizontal 2D Euclidean distance between two 3D vectors.
     */
    public static double horizontalDistance(Vec3 from, Vec3 to) {
        double dx = to.x - from.x;
        double dz = to.z - from.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * Calculates the horizontal distance squared.
     */
    public static double horizontalDistanceSquared(Vec3 from, Vec3 to) {
        double dx = to.x - from.x;
        double dz = to.z - from.z;
        return dx * dx + dz * dz;
    }

    /**
     * Normalizes a yaw angle to the range [-180, 180).
     */
    public static float wrapDegrees(float angle) {
        float wrapped = angle % 360.0F;
        if (wrapped >= 180.0F) {
            wrapped -= 360.0F;
        }
        if (wrapped < -180.0F) {
            wrapped += 360.0F;
        }
        return wrapped;
    }

    /**
     * Computes the absolute difference between two angles in degrees [0, 180].
     */
    public static float angleDistance(float angle1, float angle2) {
        float diff = Math.abs(wrapDegrees(angle1) - wrapDegrees(angle2));
        if (diff > 180.0F) {
            diff = 360.0F - diff;
        }
        return diff;
    }

    /**
     * Calculates the Euclidean distance from a ray origin to the closest point on an Axis-Aligned Bounding Box (AABB).
     * If the ray origin is inside the box, the distance is 0.0.
     */
    public static double distanceToAABB(Vec3 eyePos, AABB box) {
        double closestX = clamp(eyePos.x, box.minX, box.maxX);
        double closestY = clamp(eyePos.y, box.minY, box.maxY);
        double closestZ = clamp(eyePos.z, box.minZ, box.maxZ);

        double dx = eyePos.x - closestX;
        double dy = eyePos.y - closestY;
        double dz = eyePos.z - closestZ;

        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /**
     * Computes the angle in degrees between a look direction vector and the vector pointing towards a target position.
     */
    public static double angleBetween(Vec3 lookVec, Vec3 from, Vec3 target) {
        Vec3 toTarget = target.subtract(from).normalize();
        double dot = lookVec.normalize().dot(toTarget);
        dot = clamp(dot, -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    /**
     * Computes the greatest common divisor (GCD) of two non-zero positive numbers with a given precision.
     * Crucial for detecting unnatural aimbot rotations that bypass standard mouse sensitivity steps.
     */
    public static double computeGCD(double a, double b) {
        if (a < b) {
            return computeGCD(b, a);
        }
        if (Math.abs(b) < 0.0001) {
            return a;
        }
        return computeGCD(b, a - Math.floor(a / b) * b);
    }

    /**
     * Checks if a double is finite and valid (not NaN and not Infinite).
     */
    public static boolean isFinite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    /**
     * Checks if a float is finite and valid.
     */
    public static boolean isFinite(float value) {
        return !Float.isNaN(value) && !Float.isInfinite(value);
    }
}
