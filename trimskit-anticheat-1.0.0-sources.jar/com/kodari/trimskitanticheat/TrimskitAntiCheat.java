package com.kodari.trimskitanticheat;

import com.kodari.trimskitanticheat.alerts.AlertManager;
import com.kodari.trimskitanticheat.checks.CheckManager;
import com.kodari.trimskitanticheat.commands.TrimskitCommand;
import com.kodari.trimskitanticheat.config.ConfigManager;
import com.kodari.trimskitanticheat.player.PlayerDataManager;
import com.kodari.trimskitanticheat.storage.ViolationHistoryStorage;
import com.kodari.trimskitanticheat.violations.ViolationManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

/**
 * Main entrypoint for Trimskit AntiCheat on Fabric 26.2.
 */
public class TrimskitAntiCheat implements ModInitializer {

    public static final String MOD_ID = "trimskit-anticheat";
    public static final Logger LOGGER = LoggerFactory.getLogger("TrimskitAntiCheat");

    private static TrimskitAntiCheat instance;

    private ConfigManager configManager;
    private PlayerDataManager playerDataManager;
    private CheckManager checkManager;
    private ViolationManager violationManager;
    private AlertManager alertManager;
    private ViolationHistoryStorage violationStorage;
    private MinecraftServer server;

    @Override
    public void onInitialize() {
        instance = this;
        LOGGER.info("Initializing Trimskit AntiCheat for Minecraft 26.2 (Java 25)...");

        Path configDir = FabricLoader.getInstance().getConfigDir();
        this.configManager = new ConfigManager(configDir);
        this.configManager.load();

        this.playerDataManager = new PlayerDataManager();
        this.checkManager = new CheckManager();
        this.violationManager = new ViolationManager();
        this.alertManager = new AlertManager();
        this.violationStorage = new ViolationHistoryStorage(configDir.resolve("trimskit"));

        registerLifecycleEvents();
        registerCommands();

        LOGGER.info("Trimskit AntiCheat successfully initialized with {} active checks.",
                checkManager.getAllChecks().size());
    }

    private void registerLifecycleEvents() {
        ServerLifecycleEvents.SERVER_STARTING.register(serverInstance -> {
            this.server = serverInstance;
            LOGGER.info("Trimskit AntiCheat hooked into active server instance.");
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(serverInstance -> {
            if (this.playerDataManager != null) {
                this.playerDataManager.clearAll();
            }
            this.server = null;
            LOGGER.info("Trimskit AntiCheat session cleanly terminated.");
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, serverInstance) -> {
            playerDataManager.registerPlayer(handler.getPlayer(), serverInstance.getTickCount());
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, serverInstance) -> {
            playerDataManager.removePlayer(handler.getPlayer().getUUID());
        });

        ServerTickEvents.END_SERVER_TICK.register(serverInstance -> {
            playerDataManager.tick(serverInstance, serverInstance.getTickCount());
        });
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            TrimskitCommand.register(dispatcher);
        });
    }

    public static TrimskitAntiCheat getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public CheckManager getCheckManager() {
        return checkManager;
    }

    public ViolationManager getViolationManager() {
        return violationManager;
    }

    public AlertManager getAlertManager() {
        return alertManager;
    }

    public ViolationHistoryStorage getViolationStorage() {
        return violationStorage;
    }

    public MinecraftServer getServer() {
        return server;
    }
}
