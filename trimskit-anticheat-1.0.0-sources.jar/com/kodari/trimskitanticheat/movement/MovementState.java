package com.kodari.trimskitanticheat.movement;

import com.kodari.trimskitanticheat.util.MathUtil;
import net.minecraft.world.phys.Vec3;

/**
 * Snapshot of a player's kinematic movement state for a tick or movement packet.
 */
public class MovementState {

    private Vec3 from = Vec3.ZERO;
    private Vec3 to = Vec3.ZERO;
    private float yaw;
    private float pitch;
    private float lastYaw;
    private float lastPitch;

    private double deltaX;
    private double deltaY;
    private double deltaZ;
    private double deltaXZ;

    private boolean clientOnGround;
    private boolean serverOnGround;
    private boolean lastClientOnGround;
    private boolean lastServerOnGround;

    private int airTicks;
    private int groundTicks;
    private float serverFallDistance;

    public void update(Vec3 newPos, float newYaw, float newPitch, boolean clientGround, boolean serverGround) {
        this.from = this.to == Vec3.ZERO ? newPos : this.to;
        this.to = newPos;

        this.lastYaw = this.yaw;
        this.lastPitch = this.pitch;
        this.yaw = newYaw;
        this.pitch = newPitch;

        this.deltaX = to.x - from.x;
        this.deltaY = to.y - from.y;
        this.deltaZ = to.z - from.z;
        this.deltaXZ = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);

        this.lastClientOnGround = this.clientOnGround;
        this.lastServerOnGround = this.serverOnGround;
        this.clientOnGround = clientGround;
        this.serverOnGround = serverGround;

        if (serverGround) {
            this.airTicks = 0;
            this.groundTicks++;
            this.serverFallDistance = 0.0F;
        } else {
            this.groundTicks = 0;
            this.airTicks++;
            if (deltaY < 0.0) {
                this.serverFallDistance += (float) Math.abs(deltaY);
            }
        }
    }

    public Vec3 getFrom() { return from; }
    public Vec3 getTo() { return to; }
    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    public float getLastYaw() { return lastYaw; }
    public float getLastPitch() { return lastPitch; }
    public float getDeltaYaw() { return MathUtil.angleDistance(yaw, lastYaw); }
    public float getDeltaPitch() { return Math.abs(pitch - lastPitch); }

    public double getDeltaX() { return deltaX; }
    public double getDeltaY() { return deltaY; }
    public double getDeltaZ() { return deltaZ; }
    public double getDeltaXZ() { return deltaXZ; }

    public boolean isClientOnGround() { return clientOnGround; }
    public boolean isServerOnGround() { return serverOnGround; }
    public boolean wasClientOnGround() { return lastClientOnGround; }
    public boolean wasServerOnGround() { return lastServerOnGround; }

    public int getAirTicks() { return airTicks; }
    public int getGroundTicks() { return groundTicks; }
    public float getServerFallDistance() { return serverFallDistance; }

    public void resetAirTicks() {
        this.airTicks = 0;
        this.serverFallDistance = 0.0F;
    }
}
