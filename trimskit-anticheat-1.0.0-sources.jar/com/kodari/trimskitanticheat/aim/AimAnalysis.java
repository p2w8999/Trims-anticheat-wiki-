package com.kodari.trimskitanticheat.aim;

import com.kodari.trimskitanticheat.util.MathUtil;

/**
 * Statistical algorithms for detecting robotic, smoothed, or algorithmic aim behavior
 * characteristic of Vape V4 and advanced combat clients.
 */
public final class AimAnalysis {

    private AimAnalysis() {
    }

    /**
     * Calculates the sample variance of rotation deltas.
     */
    public static double calculateDeltaVariance(RotationHistory.RotationSample[] samples, boolean pitch) {
        if (samples.length < 5) {
            return -1.0;
        }

        double sum = 0.0;
        for (RotationHistory.RotationSample s : samples) {
            sum += pitch ? s.deltaPitch() : s.deltaYaw();
        }
        double mean = sum / samples.length;

        double sumSqDiff = 0.0;
        for (RotationHistory.RotationSample s : samples) {
            double val = pitch ? s.deltaPitch() : s.deltaYaw();
            sumSqDiff += (val - mean) * (val - mean);
        }

        return sumSqDiff / (samples.length - 1);
    }

    /**
     * Estimates GCD consistency over recent pitch/yaw deltas.
     * Legitimate mouse input produces GCD steps matching the game's sensitivity multiplier.
     * Algorithmic aim-assist often introduces fractional angles that fail GCD alignment.
     */
    public static double computeAverageGCD(RotationHistory.RotationSample[] samples) {
        if (samples.length < 10) {
            return -1.0;
        }

        double runningGcd = 0.0;
        int validCount = 0;

        for (int i = 1; i < samples.length; i++) {
            float d1 = samples[i].deltaPitch();
            float d2 = samples[i - 1].deltaPitch();

            if (d1 > 0.05F && d2 > 0.05F) {
                double gcd = MathUtil.computeGCD(d1, d2);
                if (gcd > 0.001) {
                    runningGcd += gcd;
                    validCount++;
                }
            }
        }

        return validCount > 0 ? (runningGcd / validCount) : -1.0;
    }

    /**
     * Validates whether the pitch angle is within legal Minecraft boundaries [-90.0, 90.0].
     */
    public static boolean isPitchLegal(float pitch) {
        return MathUtil.isFinite(pitch) && pitch >= -90.0F && pitch <= 90.0F;
    }
}
