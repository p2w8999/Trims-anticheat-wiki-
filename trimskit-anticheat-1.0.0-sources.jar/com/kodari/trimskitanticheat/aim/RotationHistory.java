package com.kodari.trimskitanticheat.aim;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Bounded circular buffer of recent yaw and pitch rotations for statistical aim analysis.
 */
public class RotationHistory {

    private static final int MAX_HISTORY_SIZE = 40;

    public record RotationSample(float yaw, float pitch, float deltaYaw, float deltaPitch, long timestampMs) {}

    private final Deque<RotationSample> samples = new ArrayDeque<>(MAX_HISTORY_SIZE);

    public synchronized void addSample(float yaw, float pitch, float deltaYaw, float deltaPitch) {
        if (samples.size() >= MAX_HISTORY_SIZE) {
            samples.pollFirst();
        }
        samples.addLast(new RotationSample(yaw, pitch, deltaYaw, deltaPitch, System.currentTimeMillis()));
    }

    public synchronized RotationSample[] getRecentSamples() {
        return samples.toArray(new RotationSample[0]);
    }

    public synchronized int size() {
        return samples.size();
    }

    public synchronized void clear() {
        samples.clear();
    }
}
